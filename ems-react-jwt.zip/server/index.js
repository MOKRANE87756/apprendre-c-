const express = require('express')
const jwt = require('jsonwebtoken')
const bodyParser = require('body-parser')
const cors = require('cors')

const app = express()
app.use(cors({ origin: ['http://localhost:5173'], credentials: true }))
app.use(bodyParser.json())

const SECRET = 'replace_this_with_a_strong_secret'

app.post('/server/api/login', (req,res)=>{
  const { username, password } = req.body
  if(username === 'demo_club' && password === 'demo1234'){
    const payload = { username: 'demo_club', name: 'نادي تجريبي' }
    const token = jwt.sign(payload, SECRET, { expiresIn: '2h' })
    return res.json({ token })
  }
  return res.status(401).json({ message: 'بيانات اعتماد غير صحيحة' })
})

app.get('/server/api/check', (req,res)=>{
  const auth = req.headers.authorization
  if(!auth) return res.status(401).json({ message: 'مفقود' })
  const token = auth.replace('Bearer ','')
  try{
    const payload = jwt.verify(token, SECRET)
    return res.json({ ok:true, user: payload })
  } catch(err){ return res.status(401).json({ message: 'توكين غير صالح' }) }
})

app.listen(4000, ()=>console.log('API server listening on http://localhost:4000'))