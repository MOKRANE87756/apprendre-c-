import React, {useState} from 'react'
import { useAuth } from '../lib/auth'
import { useNavigate } from 'react-router-dom'

export default function LoginCard(){
  const { login, demo } = useAuth();
  const navigate = useNavigate()
  const [username,setUsername] = useState('')
  const [password,setPassword] = useState('')
  const [err,setErr] = useState(null)

  async function onSubmit(e){
    e.preventDefault(); setErr(null)
    try{
      await login(username, password)
      navigate('/dashboard')
    } catch(er){
      setErr(er.message || 'خطأ في تسجيل الدخول')
    }
  }

  function onDemo(){
    demo()
    navigate('/dashboard')
  }

  return (
    <div className="max-w-4xl w-full bg-white shadow-md rounded-2xl grid grid-cols-1 md:grid-cols-2 overflow-hidden">
      <div className="p-8">
        <div className="flex items-center gap-4 mb-6">
          <div className="w-16 h-16 rounded-lg bg-gradient-to-br from-blue-700 to-blue-400 flex items-center justify-center text-white font-bold">FAF</div>
          <div>
            <div className="font-bold">الفدرالية الجزائرية لكرة القدم</div>
            <div className="text-sm text-slate-500">منصة EMS — ورقة المباراة الإلكترونية</div>
          </div>
        </div>
        <h2 className="text-2xl font-semibold text-slate-800">أهلاً بك</h2>
        <p className="text-sm text-slate-500 mt-2">قم بتسجيل الدخول للوصول إلى لوحة التحكم وإدارة المباريات.</p>
      </div>

      <div className="p-8 bg-slate-50">
        <form onSubmit={onSubmit} className="space-y-4">
          {err && <div className="text-sm text-red-600">{err}</div>}
          <div>
            <label className="block text-sm text-slate-600">اسم المستخدم</label>
            <input value={username} onChange={e=>setUsername(e.target.value)} className="w-full mt-2 p-3 rounded-lg border" placeholder="club123" />
          </div>
          <div>
            <label className="block text-sm text-slate-600">كلمة المرور</label>
            <input type="password" value={password} onChange={e=>setPassword(e.target.value)} className="w-full mt-2 p-3 rounded-lg border" placeholder="••••••••" />
          </div>
          <div className="flex gap-3">
            <button className="flex-1 p-3 rounded-lg bg-blue-700 text-white" type="submit">تسجيل الدخول</button>
            <button type="button" onClick={onDemo} className="p-3 rounded-lg border">تجريبي</button>
          </div>
        </form>
      </div>
    </div>
  )
}