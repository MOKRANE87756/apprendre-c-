import React from 'react'
import LoginCard from '../ui/LoginCard'

export default function App(){
  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
      <LoginCard />
    </div>
  )
}