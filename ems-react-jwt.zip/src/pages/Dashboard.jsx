import React from 'react'
import { useAuth } from '../lib/auth'

export default function Dashboard(){
  const { logout, user } = useAuth();
  return (
    <div className="min-h-screen p-8 bg-slate-50">
      <div className="max-w-6xl mx-auto bg-white p-6 rounded-lg shadow">
        <div className="flex justify-between items-center mb-6">
          <h1 className="font-bold">لوحة التحكم</h1>
          <div className="flex gap-3 items-center">
            <div className="text-sm text-slate-600">مرحباً، {user?.name || user?.username}</div>
            <button onClick={logout} className="text-sm px-3 py-2 border rounded">تسجيل خروج</button>
          </div>
        </div>
        <div>محتوى لوحة التحكم (مثال)</div>
      </div>
    </div>
  )
}