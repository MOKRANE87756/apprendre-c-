import React from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import App from './pages/App'
import Dashboard from './pages/Dashboard'
import { AuthProvider, useAuth } from './lib/auth'
import './styles.css'

function Protected({ children }){
  const { token, loading } = useAuth();
  if(loading) return <div className="p-6">جارٍ التحقق...</div>
  return token ? children : <Navigate to="/" replace />
}

createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<App/>} />
          <Route path="/dashboard" element={<Protected><Dashboard/></Protected>} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  </React.StrictMode>
)